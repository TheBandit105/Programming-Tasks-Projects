        //display result 
         function dis(val) 
         { 
             document.getElementById("result").value+=val;
         } 
           
         //count the digit and give back the result 
         function solve() 
         { 
             let x = document.getElementById("result").value 
             let y = eval(x) 
             document.getElementById("result").value = y;
         } 
           
         //clears the display 
         function clr() 
         { 
             document.getElementById("result").value = "";
         } 